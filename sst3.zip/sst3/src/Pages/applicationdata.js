// tasksData.js

const tasksData = [
  {
    task: "Call Sam For payments",
    priority: "High priority",
  },
  {
    task: "Make payment to Bluedart",
    priority: "Low priority",
  },
  {
    task: "Office rent",
    priority: "Middle priority",
  },
  {
    task: "Office rent",
    priority: "Middle priority",
  },
  {
    task: "Office rent",
    priority: "Middle priority",
  },
  {
    task: "Office rent",
    priority: "Middle priority",
  },
  {
    task: "Office rent",
    priority: "Middle priority",
  },
  // Add more tasks as needed
];
// activityData.js

export { tasksData };
